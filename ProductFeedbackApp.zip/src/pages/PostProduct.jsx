// src/pages/PostProduct.jsx
import React from "react";

export default function PostProduct() {
  return (
    <div>
      <h1>Post a New Product</h1>
      <form>
        <input type="text" placeholder="Product name" /><br />
        <textarea placeholder="Product description"></textarea><br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
