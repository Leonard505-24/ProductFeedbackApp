# Product Feedback App

This is a prototype app where companies can post products and the public can leave reviews and feedback.

## Features
- Companies can post products
- Users can browse products
- Users can leave reviews

## Tech Stack
- React
- React Router
