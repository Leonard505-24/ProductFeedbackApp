# Product Feedback App

React app where companies can post products and users can leave reviews.
