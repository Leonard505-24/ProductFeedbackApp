// src/pages/Signup.jsx
import React from "react";

export default function Signup() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Signup</h1>
      <form>
        <input type="text" placeholder="Username" /><br /><br />
        <input type="email" placeholder="Email" /><br /><br />
        <input type="password" placeholder="Password" /><br /><br />
        <button type="submit">Signup</button>
      </form>
    </div>
  );
}
