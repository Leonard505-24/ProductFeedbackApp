// src/pages/PostProduct.jsx
import React from "react";

export default function PostProduct() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Post a New Product</h1>
      <form>
        <input type="text" placeholder="Product name" /><br /><br />
        <textarea placeholder="Product description"></textarea><br /><br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
