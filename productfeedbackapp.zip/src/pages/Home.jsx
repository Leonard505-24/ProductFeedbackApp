// src/pages/Home.jsx
import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Product Feed</h1>
      <p>This is where all products will be listed.</p>
      <Link to="/product/1">Go to sample product</Link>
    </div>
  );
}
